create function check_condition() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM CONDITION_CHANGE
        WHERE CR_ID = NEW.CR_ID
        AND WHEN_EXECUTED <= NEW.WHEN_EXECUTED
        AND END_CONDITION_ID = (SELECT COND_ID FROM CONDITIONS WHERE DESCRIPTION = 'Откис')
    ) THEN
        RAISE EXCEPTION 'Мёртвое существо не может есть';
    ELSE
        RETURN NEW;
    END IF;
END;
$$;

alter function check_condition() owner to s412905;

