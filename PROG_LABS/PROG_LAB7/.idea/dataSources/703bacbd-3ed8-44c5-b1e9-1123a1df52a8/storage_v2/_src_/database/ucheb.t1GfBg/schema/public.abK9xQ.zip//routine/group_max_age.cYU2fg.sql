create function group_max_age(gr_id integer) returns integer
    language plpgsql
as
$$
Begin
    return (select max(date_part('year', age("Н_ЛЮДИ"."ДАТА_РОЖДЕНИЯ"))::int) from "Н_УЧЕНИКИ" inner join "Н_ЛЮДИ" on "Н_УЧЕНИКИ"."ЧЛВК_ИД" = "Н_ЛЮДИ"."ИД" where "Н_УЧЕНИКИ"."ЧЛВК_ИД" = gr_id);
End;
$$;

alter function group_max_age(integer) owner to s311769;

