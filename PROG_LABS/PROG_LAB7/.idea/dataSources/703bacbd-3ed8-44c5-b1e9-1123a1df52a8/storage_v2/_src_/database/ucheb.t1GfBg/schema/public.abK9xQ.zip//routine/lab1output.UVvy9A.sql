create function lab1output(name text) returns void
    language plpgsql
as
$$
declare
row record;

begin
raise info 'NO.    Имя Столбца       Атрибуты';
raise info '--     -----------       -------------------';
for row in select row_number() over (order by attname) as row,
pg_attribute.attname,
pg_type.typname,
pg_attribute.attnotnull,
pg_description.description


from pg_attribute

join pg_class on pg_class.oid  = pg_attribute.attrelid
join pg_type on pg_type.oid = pg_attribute.atttypid
left join pg_description on pg_description.objoid = pg_class.oid and pg_description.objsubid = pg_attribute.attnum

where relname = name

  loop
raise info '% % % Type: %  ', format('%-6s',row.row), format('%-15s',row.attname), '.' ,row.typname;
raise info '% % % ', '.', format('%40s', 'Not null?'),row.attnotnull;
if row.description IS NOT NULL then raise info '% % %   ','.', format('%41s','COMMEN:'), row.description;
end if;

  end loop;

end
$$;

alter function lab1output(text) owner to s270247;

