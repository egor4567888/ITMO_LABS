create function plan_count(id integer) returns integer
    language plpgsql
as
$$
Begin
    return (select count(*) from "Н_ГРУППЫ_ПЛАНОВ" where "ПЛАН_ИД" = id);
End;
$$;

alter function plan_count(integer) owner to s311769;

