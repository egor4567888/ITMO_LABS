create function showinfoaboutkeys(scheme_name text) returns void
    language plpgsql
as
$$
        declare
            column_info record;
        begin
            if (not exists(select * from pg_namespace where nspname = scheme_name)) then
                raise exception 'схема % не найдена', scheme_name;
            else
                raise info 'Имя ограничения                     Тип   Имя Столбца    Имя Таблицы          Имя Таблицы          Имя столбца';
                raise info '---------------------------------- ----- -------------- -------------------- -------------------- ---------------';
                for column_info in
                    SELECT conname,
                           contype,
                           a.attname,
                           conrelid::regclass,
                           confrelid::regclass,
                           aa.attname
                    FROM pg_constraint
                             JOIN pg_index i ON i.indrelid = conrelid::regclass
                             JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY (i.indkey)
                             LEFT JOIN pg_index ii ON ii.indrelid = confrelid::regclass
                             LEFT JOIN pg_attribute aa ON aa.attrelid = ii.indrelid AND aa.attnum = ANY (i.indkey)
                    WHERE contype IN ('f', 'p')
                      AND connamespace = scheme_name::regnamespace
                    ORDER BY conname
                    loop
                        if (column_info.contype = 'p') then
                            raise info '% P    % %', rpad(column_info.conname, 35, ' '), rpad(column_info.attname, 15, ' '), rpad(column_info.conrelid::text, 20, ' ');
                        else
                            raise info '% R    % % % %', rpad(column_info.conname, 35, ' '), rpad(column_info.attname, 15, ' '), rpad(column_info.conrelid::text, 20, ' '), rpad(column_info.confrelid::text, 20, ' '), rpad(column_info.attname, 15, ' ');
                        end if;
                    end loop;
            end if;
        end
        $$;

alter function showinfoaboutkeys(text) owner to s264465;

