create function lab2(sch character varying DEFAULT 's100000'::character varying) returns void
    language plpgsql
as
$$

    declare
        count int := 1;
        null_counter int;
        -- get list of tables in schema
        tables cursor for (select tablename from pg_catalog.pg_tables where schemaname = sch);
    begin
        if (select count(*) from information_schema.tables where table_schema = sch) < 1
        then raise exception 'Таблиц нет в данной схеме';
        end if;

        raise notice 'Схема: %',sch;
        raise notice '   ';

        raise notice 'No. Имя таблицы';
        raise notice '--- -------------------------------';

        for row in tables
            loop
                execute format('SELECT * from %I
                            except
                            SELECT * from %I where %I is not null',
                               row.tablename, row.tablename, row.tablename)
                    into null_counter;
                if null_counter > 0
                then
                    raise notice '% %', lpad(count::text, 3, ' '), row.tablename;
                    count = count + 1;
                end if;
            end loop;
    end;

$$;

alter function lab2(varchar) owner to s284409;

