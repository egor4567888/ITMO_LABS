create procedure lab1_ekh_no_distinct(IN other_user name)
    language plpgsql
as
$$
DECLARE
rec record;
BEGIN
      raise info 'Текущий пользователь: %', (select current_user);
      raise info 'Кому выдаём права доступа: %', other_user;
      raise info '

        No.    Имя таблицы';
      raise info '--- ----------------------------------';
      for rec in select distinct on (name) row_number() OVER(order by table_name) as "num", table_name as "name", privilege_type as "type" FROM information_schema.table_privileges where is_grantable = 'YES'
      LOOP
      raise info '%   %   %', rec.num, rec.name, rec.type;
      END LOOP;
END
$$;

alter procedure lab1_ekh_no_distinct(name) owner to s284745;

