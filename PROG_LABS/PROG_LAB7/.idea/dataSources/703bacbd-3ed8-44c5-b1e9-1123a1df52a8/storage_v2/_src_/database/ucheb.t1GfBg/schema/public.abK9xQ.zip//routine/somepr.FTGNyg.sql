create procedure somepr()
    language plpgsql
as
$$
DECLARE 
	number integer := 1;
BEGIN
	RAISE NOTICE 'j%', number;
	SELECT pg_class.relfilenode FROM pg_class;
END;
$$;

alter procedure somepr() owner to s285638;

