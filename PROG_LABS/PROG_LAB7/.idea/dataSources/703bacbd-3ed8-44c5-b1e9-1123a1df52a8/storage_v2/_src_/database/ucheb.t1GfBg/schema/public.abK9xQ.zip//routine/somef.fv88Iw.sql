create function somef(tablename character varying) returns void
    language plpgsql
as
$$
DECLARE 
	number integer := 1;
	row record;
	descr varchar;
	columnName varchar;
	data varchar;
	i record;
	position integer;
	obId integer;
	nameIndex varchar;
	
BEGIN
	RAISE NOTICE 'No  columnName      attributes';
	RAISE NOTICE '--- -----------     ------------------------------------------------------';
	for row in SELECT columns.column_name, columns.data_type FROM information_schema.columns WHERE columns.table_name=tableName
		loop
			columnName := row.column_name;
			data := row.data_type;
			SELECT ordinal_position INTO position FROM information_schema.columns WHERE columns.table_name=tableName AND column_name = columnName;
			SELECT oid INTO obId FROM pg_class WHERE relname = tableName AND relnamespace =
					(
						SELECT oid FROM pg_catalog.pg_namespace WHERE nspname = 'public'
					);  	
			SELECT description INTO descr FROM pg_catalog.pg_description WHERE objsubid = position and objoid = obId;
			SELECT relname INTO nameIndex FROM pg_class WHERE oid = 
				(
					SELECT indexrelid FROM pg_index WHERE indrelid = obId  and ARRAY[position] && indkey::int[]
 				);
			descr := concat('Commen  :  ', descr);
			nameIndex := concat('Index   :  ', nameIndex); 
			RAISE NOTICE '% % Type    :  %', rpad(to_char(number, '99'), 3, ' '), rpad(columnName, 15, ' '), data;
			RAISE NOTICE '%', lpad(descr, 20 + length(descr), ' ');
			RAISE NOTICE '%', lpad(nameIndex, 20 + length(nameIndex), ' ');
			RAISE NOTICE '';
			RAISE NOTICE '';			
			number := number + 1;
		end loop;
END
$$;

alter function somef(varchar) owner to s285638;

