create function group_average_age(gr_id character varying) returns integer
    language plpgsql
as
$$
Begin
    return (
        with ages as (select (date_part('year', age("Н_ЛЮДИ"."ДАТА_РОЖДЕНИЯ"))::int) as age from "Н_УЧЕНИКИ" inner join "Н_ЛЮДИ" on "Н_УЧЕНИКИ"."ЧЛВК_ИД" = "Н_ЛЮДИ"."ИД" where "Н_УЧЕНИКИ"."ГРУППА" = gr_id)
        select avg(age) from ages);
End;
$$;

alter function group_average_age(varchar) owner to s311769;

