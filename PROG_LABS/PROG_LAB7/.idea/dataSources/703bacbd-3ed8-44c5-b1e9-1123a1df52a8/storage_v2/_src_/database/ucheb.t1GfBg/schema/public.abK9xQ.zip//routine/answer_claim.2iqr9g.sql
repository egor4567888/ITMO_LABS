create procedure answer_claim(IN claim_id bigint, IN claim_data character varying)
    language sql
as
$$
	insert into claim (pair, status, type, member_in, member_out, data, created_date)
					values (claim_id, 1, (select c.type from claim as c where c.id = claim_id), 
						(select c.member_in from claim as c where c.id = claim_id), 
						(select c.member_out from claim as c where c.id = claim_id),
						claim_data, now());
	update claim set pair = (select c.id from claim as c where c.pair = claim_id) where id = claim_id; 
$$;

alter procedure answer_claim(bigint, varchar) owner to s264922;

