create procedure lab1_ekh(IN other_user name)
    language plpgsql
as
$$
DECLARE
rec record;
BEGIN
      raise info 'Текущий пользователь: %', (select current_user);
      raise info 'Кому выдаём права доступа: %', other_user;
      raise info '

     No. Имя таблицы';
      raise info '--- -------------------------';
      for rec in select DISTINCT ON (name) dense_rank() OVER(order by table_name) as "num", table_name as "name" FROM information_schema.table_privileges where is_grantable = 'YES'
      LOOP
      raise info '%   %', rec.num, rec.name;
      END LOOP;
END
$$;

alter procedure lab1_ekh(name) owner to s284745;

