create function is_action_allowed(person_id bigint, permission_code bigint) returns boolean
    language sql
as
$$
	select exists (
		select * from (
			select ct.code from (
					select * from person where person.id = person_id
				) as p
				join role_person_link as rpl on rpl.person = p.id
				join person_roles as pr on rpl.person_role = pr.id
				join per_role_type_link as prtl on prtl.person_role  = pr.id
				join claim_type as ct on prtl.claim_type = ct.code
			union
			select ct.code from (
					select * from person where person.id = person_id
				) as p
				join org_person_link as opl on opl.person = p.id
				join organization as o on opl.organization = o.id
				join org_type_link as otl on otl.organization = o.id
				join claim_type as ct on otl.claim_type = ct.code
		) as permission 
		where permission.code = permission_code
	) as result;
$$;

alter function is_action_allowed(bigint, bigint) owner to s264922;

