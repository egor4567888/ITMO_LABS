create function thirdquestion() returns character varying
    language plpgsql
as
$$
BEGIN
    IF EXISTS(
            SELECT l."ИМЯ"
            FROM "Н_ЛЮДИ" l
                     LEFT JOIN "Н_УЧЕНИКИ" u on l."ИД" = u."ЧЛВК_ИД"
            WHERE u."ГРУППА" = '3102'
              AND EXTRACT(year from (age(l."ДАТА_РОЖДЕНИЯ"))) < 20
        )
    THEN
        return 'В группе 3012 существуют студенты младше 20';
    ELSE
        return 'В группе 3012 не существует студентов младше 20';
    END IF;
END;
$$;

alter function thirdquestion() owner to s308511;

