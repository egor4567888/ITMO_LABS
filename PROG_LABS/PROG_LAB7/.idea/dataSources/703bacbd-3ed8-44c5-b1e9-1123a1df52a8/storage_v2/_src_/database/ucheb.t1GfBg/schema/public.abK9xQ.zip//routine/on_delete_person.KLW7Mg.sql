create function on_delete_person() returns trigger
    language plpgsql
as
$$
	declare claim_iterator record;
    begin
		if TG_OP = 'UPDATE' and NEW.is_deleted = true and OLD.is_deleted = false or TG_OP = 'DELETE' then
		    for claim_iterator in select * from claim as c
				where c.data like concat('%', OLD.name, '%')
					and c.status <> 3
					and pair is null
			loop
				update claim set status = 4 where id = claim_iterator.id;
				insert into claim (pair, status, type, member_in, member_out, data, created_date)
					values (claim_iterator.id, 4, claim_iterator.type, claim_iterator.member_out, 
							claim_iterator.member_in, 'temp', now());
                update claim set pair = (select claim.id from claim where data='temp') where id = claim_iterator.id;
				update claim set data='Пользователь участвующий во взаимодействии был удален, пожалуйста, перенаправьте заявление!'
                    where id=(select claim.id from claim where data='temp');
			end loop;
			return NEW;
		end if;
		return NULL;
	end;
$$;

alter function on_delete_person() owner to s264922;

